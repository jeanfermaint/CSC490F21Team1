/*
	RocketFlightBLE - library to manage the Rocket Flight BLE communications 
		with the Rocket Central controller.
*/

#include <ArduinoBLE.h>
#define DEBUG false
#define MAXBLESIZE 200

class RocketFlightBLE {

  private:
    BLEService flightService{"19B10000-E8F2-537E-4F6C-D104768A1214"}; // BLE Rocket Flight Service
    
    // BLE Rocket Flight Characteristic - custom 128-bit UUID, read and writable by central
    BLEByteCharacteristic switchCharacteristic{"19B10001-E8F2-537E-4F6C-D104768A1214", BLERead | BLEWrite};
    BLECharacteristic valueCharacteristic{"533f9659-097b-4a4f-b51a-e5bdec9dabd3", BLERead | BLEWrite, MAXBLESIZE, false};
    BLEByteCharacteristic hasDataCharacteristic{"a7e5cbfb-c512-42b2-b7c0-a54fa98b0416", BLERead | BLEWrite};
    BLEByteCharacteristic requestDataCharacteristic{"684418b7-8ce4-471c-8b6a-1d0a6c5b99a0", BLERead | BLEWrite};
    BLEByteCharacteristic ackDataCharacteristic{"32cd7079-594c-47a3-888c-5f504d5f7f92", BLERead | BLEWrite};
    BLEByteCharacteristic readReadyCharacteristic{"da259cce-3b45-4db1-a9ff-d3d3df0d9f63", BLERead | BLEWrite};
    BLELongCharacteristic clockCharacteristic{"c822afa5-47fc-4fb4-8bc8-556339e28703", BLERead | BLEWrite};
    BLEIntCharacteristic stateCharacteristic{"96e2f229-e933-4ddc-a482-7f1607d4ccb8", BLERead | BLEWrite};
    BLEIntCharacteristic pressureCharacteristic{"07545f0a-f5b3-400e-97e9-2ee419e60acc", BLERead | BLEWrite};
    BLEIntCharacteristic launchRequestCharacteristic{"c2e2e056-f748-4ce1-9d46-7865d064d3d2", BLERead | BLEWrite};
    BLEByteCharacteristic armRocketCharacteristic{"91c84e7c-9417-46ad-ac98-326a12a78ef6", BLERead | BLEWrite};
    
    // State Values
    #define COMM_NONE 0
    #define DATA_REQ 1
    #define READ_READY 5
    #define HAS_DATA 7
    #define DATA_READ 10
    #define DATA_WRITE 12
    #define DATA_ACK 15
    #define DATA_DONE 20

    byte *bytePtr;
    const int ledPin = LED_BUILTIN; // pin to use for the LED
    int writeCount = 0;
    
    int commState = COMM_NONE;
    int prevState = -1;
    bool haveData = false;
    BLEDevice central;

    void MsgWrite(char* msg) {
      if (DEBUG) {
        Serial.print(msg);
      }
    };
    void MsgWriteln(char* msg) {
      if (DEBUG) {
        Serial.println(msg);
      }
    };
    void MsgWriteln(int data) {
      if (DEBUG) {
        Serial.println(data);
      }
    };
    void MsgWriteln(arduino::String msg) {
      if (DEBUG) {
        Serial.print(msg);
      }
    };
    
  public:
    int setupBLE(void);
    bool connectedBLE(void);
    bool transferBLE(byte*, int);
    void setClock(long);
    void setPressure(int);
    void setState(int);
    bool getLaunchRequest();
	void setHasData(bool);
	bool armRocketSet();
};