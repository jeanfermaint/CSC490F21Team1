/*
	RocketFlightBLE - library to manage the Rocket Flight BLE communications 
		with the Rocket Central controller.
*/

#include <ArduinoBLE.h>
#include <RocketFlightBLE.h>
#define DEBUG true

int RocketFlightBLE::setupBLE(void) {
  const int ledPin = LED_BUILTIN;
  
  // begin initialization
  if (!BLE.begin()) {
    MsgWriteln("starting BLE failed!");
    return 0;
  }

  // set advertised local name and service UUID:
  BLE.setLocalName("ROCKET-FLIGHT");
  BLE.setAdvertisedService(flightService);

  // add the characteristic to the service
  flightService.addCharacteristic(switchCharacteristic);
  flightService.addCharacteristic(valueCharacteristic);
  flightService.addCharacteristic(hasDataCharacteristic);
  flightService.addCharacteristic(requestDataCharacteristic);
  flightService.addCharacteristic(readReadyCharacteristic);
  flightService.addCharacteristic(ackDataCharacteristic);  
  
  flightService.addCharacteristic(clockCharacteristic);
  flightService.addCharacteristic(stateCharacteristic);
  flightService.addCharacteristic(pressureCharacteristic);
  flightService.addCharacteristic(launchRequestCharacteristic);
  flightService.addCharacteristic(armRocketCharacteristic);

  // add service
  BLE.addService(flightService);

  // set the initial value for the characeristic:
  switchCharacteristic.writeValue(0);
  valueCharacteristic.writeValue((byte)0x00);
  requestDataCharacteristic.writeValue((byte)0x00);
  hasDataCharacteristic.writeValue((byte)0x00);
  readReadyCharacteristic.writeValue((byte)0x00);
  armRocketCharacteristic.writeValue((byte)0x00);
  
  // start advertising
  BLE.advertise();

  MsgWriteln("BLE Rocket Flight Peripheral");
  
  return 1;
}

void RocketFlightBLE::setClock(long clk) {
  if (!clockCharacteristic.writeValue(clk)) {
    MsgWriteln("Clock write fail");
  }
}

void RocketFlightBLE::setPressure(int pressure) {
  if (!pressureCharacteristic.writeValue(pressure)) {
    MsgWriteln("Pressure write fail");
  }
}

void RocketFlightBLE::setState(int state) {
  if (!stateCharacteristic.writeValue(state)) {
    MsgWriteln("State write fail");
  }
}

bool RocketFlightBLE::armRocketSet() {
	if (armRocketCharacteristic.written()) {
		return (bool)armRocketCharacteristic.value();
	}
	return false;
}

bool RocketFlightBLE::getLaunchRequest() {
  return (bool)launchRequestCharacteristic.value();
}

bool RocketFlightBLE::connectedBLE(void) {
  // listen for BLE peripherals to connect:
  central = BLE.central();

  return (central && central.connected());
}

void RocketFlightBLE::setHasData(bool dataAvailable) {
	byte dataFlag;
	
	haveData = dataAvailable;
	if (haveData) {
	  dataFlag = (byte)0x01;
	} else {
	  dataFlag = (byte)0x00;
	}
	
    if (!hasDataCharacteristic.writeValue(dataFlag)) {
      MsgWriteln("has data set failed");
    } else {
      MsgWriteln("has data set");
    }

}

bool RocketFlightBLE::transferBLE(byte* byteData, int dataSize) {
  const int ledPin = LED_BUILTIN;
  
  bool outputTest = true;
  char msgbuffer[80];
  byte dataFlag;
  int xferSize;
  
  // if a central is connected to peripheral:
  if (central) {
    MsgWrite("Connected to central: ");
    // print the central's MAC address:
    MsgWriteln(central.address());

    // while the central is still connected to peripheral:
    while (central.connected()) {
      // if the remote device wrote to the characteristic,
      // use the value to control the LED:
      if (switchCharacteristic.written()) {
        if (switchCharacteristic.value()) {   // any value other than 0
          MsgWriteln("LED on");
          //haveData = true;
          digitalWrite(ledPin, HIGH);         // will turn the LED on
        } else {                              // a 0 value
          MsgWriteln("LED off");
          digitalWrite(ledPin, LOW);          // will turn the LED off
        }
      }

      if (commState != prevState) {
        sprintf(msgbuffer, "State: %d", commState);
        MsgWriteln(msgbuffer);
        prevState = commState;
      }
      
      switch (commState) {
        case COMM_NONE:
          if (requestDataCharacteristic.value()) {
            requestDataCharacteristic.writeValue((byte)0x00);
            commState = DATA_REQ;
          }
          break;
          
        case DATA_REQ:
          if (haveData) {
            bytePtr = byteData;
            writeCount = 0;
          } else {
			break;
		  }
          commState = READ_READY;
          break;
          
        case HAS_DATA:  // Not used on peripheral
          break;
          
        case READ_READY:
          ackDataCharacteristic.writeValue((byte)0x00);
          if (readReadyCharacteristic.value()) {
            commState = DATA_WRITE;
          }
          break;
          
        case DATA_READ:
          break;

        case DATA_WRITE:
          if (writeCount >= dataSize) {
            commState = DATA_DONE;
            if (!hasDataCharacteristic.writeValue((byte)0x00)) {
              MsgWriteln("has data off write fail");
            }
            if (!valueCharacteristic.writeValue((byte)0xFF)) {
              MsgWriteln("End byte write fsil");
            }
            break;
          }
          xferSize = dataSize - writeCount; 
          xferSize = (xferSize > MAXBLESIZE) ? MAXBLESIZE : xferSize;
          MsgWriteln(xferSize);
          
          if (!valueCharacteristic.writeValue(bytePtr, xferSize)) {
            MsgWriteln("Data write fail");
          }
          writeCount += xferSize;
          bytePtr += xferSize;
          commState = DATA_ACK;
          break;
          
        case DATA_ACK:
          if (ackDataCharacteristic.value()) {
            commState = DATA_WRITE;
            ackDataCharacteristic.writeValue((byte)0x00);
          }
          break;
          
        case DATA_DONE:
          if (!hasDataCharacteristic.writeValue((byte)0x00)) {
            MsgWriteln("had data false write fail");
          }
          commState = COMM_NONE;
          haveData = false;
          writeCount = 0;
          return true;
          break;
      }
    }

    // when the central disconnects, print it out:
    MsgWrite("Disconnected from central: ");
    MsgWriteln(central.address());
	return false;
  }
}