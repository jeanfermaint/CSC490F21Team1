/*
	Rocket Central to Rocket Flight BLE comms library
*/
#include <RocketCentralFlightBLE.h>

int RocketCentralFlightBLE::setupRocketBLE() {
  // initialize the BLE hardware
  BLE.begin();

  Serial.println("BLE Central - Rocket control");

  // start scanning for peripherals
  //BLE.scanForUuid("19b10000-e8f2-537e-4f6c-d104768a1214");

  return 0;
}

bool RocketCentralFlightBLE::discoverRocket() {
  // connect to the peripheral
  Serial.println("Connecting ...");

  if (peripheral.connect()) {
    Serial.println("Connected");
  } else {
    Serial.println("Failed to connect!");
    return false;
  }

  // discover peripheral attributes
  Serial.println("Discovering attributes ...");
  if (peripheral.discoverAttributes()) {
    Serial.println("Attributes discovered");
  } else {
    Serial.println("Attribute discovery failed!");
    peripheral.disconnect();
    return false;
  }

  // retrieve the Rocket characteristics
  ledCharacteristic = peripheral.characteristic("19b10001-e8f2-537e-4f6c-d104768a1214");
  valueCharacteristic = peripheral.characteristic("533f9659-097b-4a4f-b51a-e5bdec9dabd3");
  hasDataCharacteristic = peripheral.characteristic("a7e5cbfb-c512-42b2-b7c0-a54fa98b0416");
  requestDataCharacteristic = peripheral.characteristic("684418b7-8ce4-471c-8b6a-1d0a6c5b99a0");
  ackDataCharacteristic = peripheral.characteristic("32cd7079-594c-47a3-888c-5f504d5f7f92");
  readReadyCharacteristic = peripheral.characteristic("da259cce-3b45-4db1-a9ff-d3d3df0d9f63");
  clockCharacteristic = peripheral.characteristic("c822afa5-47fc-4fb4-8bc8-556339e28703");
  stateCharacteristic = peripheral.characteristic("96e2f229-e933-4ddc-a482-7f1607d4ccb8");
  pressureCharacteristic = peripheral.characteristic("07545f0a-f5b3-400e-97e9-2ee419e60acc");
  launchRequestCharacteristic = peripheral.characteristic("c2e2e056-f748-4ce1-9d46-7865d064d3d2");
  armRocketCharacteristic = peripheral.characteristic("91c84e7c-9417-46ad-ac98-326a12a78ef6");

  if (!ledCharacteristic) {
    Serial.println("Peripheral does not have LED characteristic!");
    peripheral.disconnect();
    return false;
  } else if (!ledCharacteristic.canWrite()) {
    Serial.println("Peripheral does not have a writable LED characteristic!");
    peripheral.disconnect();
    return false;
  }
  if (!valueCharacteristic) {
    Serial.println("Peripheral does not have VALUE characteristic!");
    peripheral.disconnect();
    return false;
  }
  if (!hasDataCharacteristic) {
    Serial.println("Peripheral does not have HAS DATA characteristic!");
    peripheral.disconnect();
    return false;
  }
  if (!requestDataCharacteristic) {
    Serial.println("Peripheral does not have REQUEST DATA characteristic!");
    peripheral.disconnect();
    return false;
  }
  if (!readReadyCharacteristic) {
    Serial.println("Peripheral does not have READ READY characteristic!");
    peripheral.disconnect();
    return false;
  }
  if (!clockCharacteristic) {
    Serial.println("Peripheral does not have CLOCK characteristic!");
    peripheral.disconnect();
    return false;
  }
  if (!stateCharacteristic) {
    Serial.println("Peripheral does not have STATE characteristic!");
    peripheral.disconnect();
    return false;
  }
  if (!pressureCharacteristic) {
    Serial.println("Peripheral does not have PRESSURE characteristic!");
    peripheral.disconnect();
    return false;
  }
  if (!launchRequestCharacteristic) {
    Serial.println("Peripheral does not have LAUNCH REQUEST characteristic!");
    peripheral.disconnect();
    return false;
  }
  if (!armRocketCharacteristic) {
    Serial.println("Peripheral does not have ARM ROCKET characteristic!");
    peripheral.disconnect();
    return false;
  }
  return true;
}

bool RocketCentralFlightBLE::armRocket() {
	if (!armRocketCharacteristic.writeValue((byte)0x01)) {
          Serial.println("Arm rocket set fail");
	}
}

bool RocketCentralFlightBLE::launchRocket() {
	if (!launchRequestCharacteristic.writeValue((byte)0x01)) {
          Serial.println("Arm rocket set fail");
	}
}

bool RocketCentralFlightBLE::rocketConnectedBLE() {
  return bool(peripheral.connected());
}

bool RocketCentralFlightBLE::connectBLE() {
  // peripheral disconnected, start scanning again
  BLE.scanForUuid("19b10000-e8f2-537e-4f6c-d104768a1214");
  
  peripheral = BLE.available();

  if (peripheral) {
    // discovered a peripheral, print out address, local name, and advertised service
    Serial.print("Found ");
    Serial.print(peripheral.address());
    Serial.print(" '");
    Serial.print(peripheral.localName());
    Serial.print("' ");
    Serial.print(peripheral.advertisedServiceUuid());
    Serial.println();

    if (peripheral.localName() != "ROCKET-FLIGHT") {
      Serial.println("Invalid Name");
      return false;
    }

    // stop scanning
    BLE.stopScan();
    Serial.println("Begin comms");
  }
  return true;
}

bool RocketCentralFlightBLE::rocketHasData() {
  byte hasDataFlag;
  hasDataCharacteristic.readValue(hasDataFlag);
  return bool(hasDataFlag);
}

bool RocketCentralFlightBLE::receiveRocketData(byte* bytePtr, int maxSize) {
	int size;
	return receiveRocketData(bytePtr, maxSize, &size);
}

bool RocketCentralFlightBLE::receiveRocketData(byte* bytePtr, int maxSize, int* totalBytesRead) {
  char msgbuffer[80];
  
  commState = COMM_NONE;
  
  while (peripheral.connected()) {
    if (commState != prevState) {
      sprintf(msgbuffer, "State: %d", commState);
      Serial.println(msgbuffer);
      prevState = commState;
    }
    
    switch (commState) {
      case COMM_NONE:
        commState = DATA_REQ;
        break;
        
      case DATA_REQ:
        hasDataCharacteristic.readValue(hasDataFlag);
        if (hasDataFlag) 
          Serial.println("Has data");
        else
          Serial.println("No data");
        if (!requestDataCharacteristic.writeValue((byte)0x01)) {
          Serial.println("Request data set fail");
          break;
        }
        commState = HAS_DATA;
        break;
        
      case HAS_DATA:
        if(hasDataCharacteristic.value()) {
          Serial.println("Has data set");
          commState = READ_READY;
          retryCount = 0;
          readBlock = 0;
        }
        else
          commState = DATA_DONE;
        break;
        
      case READ_READY:
        if (!readReadyCharacteristic.writeValue((byte)0x01)) {
          Serial.println("Read ready set fail");
        }
        ackDataCharacteristic.writeValue((byte)0x00);
        commState = DATA_READ;
        dataAvailable = false;
        startClock = millis();
		*totalBytesRead = 0;
        break;
        
      case DATA_READ:
        if(!hasDataCharacteristic.value()) {
          Serial.println("No more data");
          commState = DATA_DONE;
        }
  
        bytesRead = valueCharacteristic.readValue(bytePtr, MAXSIZE);
        sprintf(msgbuffer, "Bytes: %d, time %d", bytesRead, millis() - startClock);
        Serial.println(msgbuffer);
        if (!bytesRead && retryCount < MAX_RETRIES) {
          commState = READ_READY;
          retryCount++;
          break;
        }
        if (bytesRead == 1 && *bytePtr == 0XFF) {
          commState = DATA_DONE;
          Serial.println("End Byte found");
          break;
        }
        readBlock++;
        bytePtr += bytesRead;
		*totalBytesRead += bytesRead;
        sprintf(msgbuffer, "Block: %d, size: %d", readBlock, bytesRead);
        Serial.println(msgbuffer);
                  
        commState = DATA_ACK;
        break;
        
      case DATA_ACK:
        if (!ackDataCharacteristic.writeValue((byte)0x01)) {
          Serial.println("ACK write fail");
        }
        startClock = millis();
        commState = DATA_READ;
        retryCount = 0;
        dataAvailable = false;
        break;
        
      case DATA_DONE:
        commState = COMM_NONE;
        return true;
        break;
        
    }  // End switch
  } // end While connected
  
  return false;
}

char* RocketCentralFlightBLE::getLastError() {
 
  return errBuffer;
}

void RocketCentralFlightBLE::setError(char* error) {
  strcpy(errBuffer, error);
}

void RocketCentralFlightBLE::setLedCharacteristic(byte byteValue) {
  ledCharacteristic.writeValue(byteValue);
}
