/*
	Rocket Central to Rocket Flight BLE communications library.
*/

#include <ArduinoBLE.h>
#define DEBUG true

// Comm State values
#define COMM_NONE 0
#define DATA_REQ 1
#define READ_READY 5
#define HAS_DATA 7
#define DATA_READ 10
#define DATA_ACK 15
#define DATA_DONE 20
#define MAXSIZE 200

#define MAX_RETRIES 5

class RocketCentralFlightBLE {
  private:
    byte hasDataFlag;
    byte dummyData;
    int bytesRead;
    int readBlock;
    bool dataAvailable;
    char errBuffer[80] = "EMPTY";
    int retryCount = 0;
    int commState = COMM_NONE;
    int prevState = -1;
    long startClock;
    
    BLEDevice peripheral;
    BLECharacteristic ledCharacteristic;
    BLECharacteristic valueCharacteristic;
    BLECharacteristic hasDataCharacteristic;
    BLECharacteristic requestDataCharacteristic;
    BLECharacteristic ackDataCharacteristic;
    BLECharacteristic readReadyCharacteristic;
    BLECharacteristic clockCharacteristic;
    BLECharacteristic stateCharacteristic;
    BLECharacteristic pressureCharacteristic;
    BLECharacteristic launchRequestCharacteristic;
	BLECharacteristic armRocketCharacteristic;
    void setError(char* error);
    
  public:
    int setupRocketBLE();
    bool connectBLE();
    bool discoverRocket();
    bool rocketConnectedBLE();
    bool rocketHasData();
    bool receiveRocketData(byte*, int);
    bool receiveRocketData(byte*, int, int*);
    char* getLastError();
    void setLedCharacteristic(byte);
	bool armRocket();
	bool launchRocket();
};
